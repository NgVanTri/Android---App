package com.example.bhd.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MovieShowDTO {
    private Integer id;
    private String imageUrl;
    private String movieName;
    private List<ShowtimeDTO> showtimes;
}
